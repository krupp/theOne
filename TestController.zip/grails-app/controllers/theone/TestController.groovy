package theone

class TestController {

    def index() {
        render 'hello worldS'
    }
}
