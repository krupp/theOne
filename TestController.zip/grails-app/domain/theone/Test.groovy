package theone

class Test {

    static constraints = {
    }
}
